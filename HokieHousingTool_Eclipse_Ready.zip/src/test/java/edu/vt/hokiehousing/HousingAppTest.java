package edu.vt.hokiehousing;

import static org.junit.jupiter.api.Assertions.*;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;
import org.junit.jupiter.api.Test;

class HousingAppTest {
    @Test
    void runListsPropertyAndExits() {
        String output = runApp("1\n0\n");
        assertTrue(output.contains("Alpha Apartments"));
        assertTrue(output.contains("Thank you"));
    }

    @Test
    void runHandlesLettersAndMissingPropertyWithoutCrashing() {
        String output = runApp("letters\n2\nFake Place\n0\n");
        assertTrue(output.contains("menu number from 0 through 5"));
        assertTrue(output.contains("Property not found"));
    }

    private String runApp(String inputText) {
        PropertyDatabase database = new PropertyDatabase();
        database.addProperty(TestData.property("Alpha Apartments", 800, 0.5));
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        HousingApp app = new HousingApp(database, new Scanner(inputText),
            new PrintStream(bytes, true, StandardCharsets.UTF_8));
        app.run();
        return bytes.toString(StandardCharsets.UTF_8);
    }
}
