# Hokie Housing Tool — 10-Minute Presentation Script

## Slide 1 — Introduction (about 20 seconds)

Hi, we are Glenn, Jovany, and Ryan. We built the Hokie Housing Tool, a Java console program that helps Virginia Tech students compare selected off-campus housing communities. We will show the design, run the MVP, explain what was difficult, and discuss what we learned from using GenAI.

## Slide 2 — What we built (about 1 minute 20 seconds)

HousingApp handles the menu and input. PropertyDatabase stores and searches Property objects. Each Property contains its TravelInfo, LandlordReport, and ReviewManager. A separate CSV file supplies the starting housing records.

The program can list and search properties, filter by rent or distance, and add resident reviews while the app is running. Keeping one main responsibility in each class made the code easier to test and divide among the team.

## Slide 3 — Scope changes (about 50 seconds)

Our original idea included live maps, current bus information, accounts, and a website. We moved those ideas to stretch goals. For the MVP, we chose a console program with five researched records and static travel estimates. The change helped us focus on working code, validation, and tests instead of spending most of the project connecting outside services.

## Slide 4 — Live demo (about 2 minutes)

First, I will type letters at the menu prompt. The app displays an error and returns to the menu instead of crashing.

Next, I will choose search and enter `Union Blacksburg`. The program displays the address, starting rent, distance, transportation, management, source, and the message `No reviews yet`.

If time allows, choose option 5, add a review, and search for Union Blacksburg again to show the new average.

Suggested input:

```text
letters
2
Union Blacksburg
5
Union Blacksburg
4
Convenient location and bus access.
2
Union Blacksburg
0
```

## Slide 5 — What went well and what did not (about 2 minutes)

The class design helped because our work division matched the code. Glenn could focus on properties and searching, Jovany could focus on the console and travel information, and Ryan could focus on landlord reports and reviews. The separate CSV also made updates easier.

The hardest lesson was that a small feature can spread through the program. Adding reviews required a Review object, a manager, validation, menu choices, display logic, and tests.

Live data looked useful on paper, but it depended on outside services and changing information. Scoping now means choosing the smallest version that is complete and testable, not listing every feature we can imagine.

## Slide 6 — What GenAI made possible (about 1 minute 15 seconds)

GenAI saved the most time by turning our written specification into a starting class structure, suggesting JUnit tests, organizing the CSV, and drafting documentation. It also identified edge cases such as a reversed rent range, a null property, a duplicate review, or letters entered where a number is required.

We could not simply accept the output. We had to understand each class, check researched facts, and decide whether the result actually matched our course scope.

## Slide 7 — What worked and what failed with GenAI (about 1 minute 15 seconds)

GenAI worked well for explanations, repeatable test cases, and fast revisions. It worked poorly when the request was too broad. Housing data changes, so the model could confidently give an old or invented number. It also tended to add complexity we did not need.

Our best process became: ask for one narrow task, inspect the answer, run the tests, and revise. The tool helped us move faster, but testing and judgment still belonged to us.

## Slide 8 — Next project (about 1 minute)

In the next project, we want to involve GenAI earlier in test planning, not only after code exists. We also want to keep the prompts and revisions so we can explain how the work changed.

For this tool, possible next steps are permanent reviews, verified live transportation data, a graphical interface, and clearer comparisons between per-bedroom and whole-unit prices. Thank you. We are ready for questions and to defend the design choices in the code.

